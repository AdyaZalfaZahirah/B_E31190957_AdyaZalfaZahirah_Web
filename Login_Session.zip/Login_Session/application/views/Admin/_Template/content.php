<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <?php echo @$konten; ?>

</div>
<!-- End of Main Content -->